const Home = () => {
  return (
    <div className="mb-20">
      <h1 className="sm:text-4xl text-2xl font-bold my-6 text-gray-900">
        Hai, welcome to My Blog ini home.jsx
      </h1>
      <p className="mx-auto leading-relaxed text-base mb-4">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, et!
        Dolorum corrupti natus illum mollitia error? Illum sint quaerat minima
        ad! Velit dolorum nisi ipsum ad accusantium, nemo ea tenetur! Lorem
        ipsum dolor, sit amet consectetur adipisicing elit. Dicta tempora
        placeat perferendis, possimus repellendus cumque cupiditate autem, animi
        sequi esse eius dolor nam ratione dignissimos voluptatibus ducimus
        beatae ut vel. Lorem ipsum dolor sit amet consectetur adipisicing elit.
        Aperiam, sed eum natus culpa vitae nulla dolor neque totam vel nesciunt
        at magni minus. Debitis quae nam adipisci suscipit aperiam quos!
      </p>
    </div>
  );
};
export default Home;
