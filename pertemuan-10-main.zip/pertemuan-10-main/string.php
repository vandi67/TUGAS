<?php

echo "Stikom" .  "Poltek" . "Cirebon";
echo "\nMy namme is:" . "Vandi";
echo "\nHello Kawan";
echo "\nsaya mau minum";
echo "\nnama saya Vandi";

$silly = "\nhai";
$biography = "\nsiang";
$favorite_food = "\n" . "sega" . "jam" . "blang";

echo "$silly";
echo "$biography";
echo "$favorite_food";
?>